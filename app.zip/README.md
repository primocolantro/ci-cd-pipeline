# ci-cd-pipeline
A CI/CD pipeline project to deploy apps with AWS CodePipeline
